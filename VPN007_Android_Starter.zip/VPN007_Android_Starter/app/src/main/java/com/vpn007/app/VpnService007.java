package com.vpn007.app;

import android.net.VpnService;

/**
 * Placeholder service declaration for the starter project.
 * A production app must integrate a maintained Xray/V2Ray core, configure its
 * TUN file descriptor and route traffic safely before claiming VPN connectivity.
 */
public class VpnService007 extends VpnService {
    @Override public void onCreate() { super.onCreate(); }
}
