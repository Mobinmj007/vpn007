package com.vpn007.app;

import android.app.Activity;
import android.content.Intent;
import android.net.VpnService;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.*;
import android.text.InputType;
import java.util.ArrayList;

public class MainActivity extends Activity {
    LinearLayout root, serverList;
    TextView status, selectedServer;
    EditText linkInput, nameInput;
    final ArrayList<String> servers = new ArrayList<>();
    int selected = -1;
    static final int VPN_REQUEST = 701;

    int dp(float v){return (int)(v*getResources().getDisplayMetrics().density+.5f);}
    TextView text(String s,int size,int color){ TextView t=new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(color); return t; }
    GradientDrawableBuilder bg(int color,int radius){return new GradientDrawableBuilder(color,dp(radius));}
    void addGap(LinearLayout box,int h){View v=new View(this);box.addView(v,new LinearLayout.LayoutParams(1,dp(h)));}
    @Override public void onCreate(Bundle b){super.onCreate(b); showHome();}
    void showHome(){
        root=new LinearLayout(this);root.setOrientation(1);root.setPadding(dp(22),dp(28),dp(22),dp(18));root.setBackgroundColor(Color.rgb(8,13,22));
        ScrollView scroll=new ScrollView(this);scroll.addView(root);setContentView(scroll);
        TextView brand=text("VPN 007",30,Color.WHITE);brand.setTypeface(null,Typeface.BOLD);root.addView(brand);
        TextView tagline=text("اتصال امن با سرور خودت",14,0xff9caec4);root.addView(tagline);
        addGap(root,26);
        LinearLayout card=new LinearLayout(this);card.setOrientation(1);card.setGravity(Gravity.CENTER);card.setPadding(dp(18),dp(20),dp(18),dp(20));card.setBackground(bg(0xff111c2d,24).drawable());root.addView(card,new LinearLayout.LayoutParams(-1,dp(205)));
        TextView shield=text("◈",42,0xff2dd4bf);card.addView(shield);
        status=text("آماده اتصال",19,Color.WHITE);status.setTypeface(null,Typeface.BOLD);card.addView(status);
        addGap(card,6);selectedServer=text("هنوز لینکی اضافه نشده",13,0xff9caec4);card.addView(selectedServer);
        addGap(root,16);
        Button connect=button("اتصال / قطع اتصال",0xff2dd4bf,0xff07121b);root.addView(connect,new LinearLayout.LayoutParams(-1,dp(54)));
        connect.setOnClickListener(v->startVpnPermission());
        addGap(root,24);
        TextView serverTitle=text("سرورها",20,Color.WHITE);serverTitle.setTypeface(null,Typeface.BOLD);root.addView(serverTitle);
        addGap(root,8);
        linkInput=new EditText(this);linkInput.setSingleLine(false);linkInput.setMinLines(2);linkInput.setTextColor(Color.WHITE);linkInput.setHintTextColor(0xff73839b);linkInput.setHint("لینک VLESS یا VMess را اینجا وارد کن");linkInput.setPadding(dp(12),dp(10),dp(12),dp(10));linkInput.setBackground(bg(0xff111c2d,14).drawable());root.addView(linkInput,new LinearLayout.LayoutParams(-1,dp(86)));
        addGap(root,8);
        Button add=button("＋ افزودن لینک سرور",0xff24364d,Color.WHITE);root.addView(add,new LinearLayout.LayoutParams(-1,dp(48)));
        add.setOnClickListener(v->{String s=linkInput.getText().toString().trim();if(!(s.startsWith("vless://")||s.startsWith("vmess://"))){Toast.makeText(this,"لینک باید با vless:// یا vmess:// شروع شود",Toast.LENGTH_LONG).show();return;}servers.add(s);selected=servers.size()-1;linkInput.setText("");refreshServers();Toast.makeText(this,"لینک در فهرست همین نشست اضافه شد",Toast.LENGTH_SHORT).show();});
        addGap(root,12);serverList=new LinearLayout(this);serverList.setOrientation(1);root.addView(serverList);
        addGap(root,20);
        TextView note=text("نسخه نمایشی رابط کاربری است. موتور Xray هنوز به پروژه متصل نشده و اتصال واقعی تا افزودن هسته سازگار برقرار نمی‌شود.",12,0xffffcc80);note.setGravity(Gravity.CENTER);root.addView(note);
    }
    Button button(String s,int color,int fg){Button b=new Button(this);b.setText(s);b.setTextColor(fg);b.setAllCaps(false);b.setTextSize(15);b.setBackground(bg(color,15).drawable());return b;}
    void refreshServers(){
        serverList.removeAllViews();
        for(int i=0;i<servers.size();i++){final int ix=i;String s=servers.get(i);String label=(i==selected?"✓  ":"")+"سرور "+(i+1)+"  •  "+s.substring(0,Math.min(s.length(),38))+"…";Button row=button(label,i==selected?0xff174c4a:0xff111c2d,Color.WHITE);serverList.addView(row,new LinearLayout.LayoutParams(-1,dp(48)));row.setOnClickListener(v->{selected=ix;selectedServer.setText("سرور "+(ix+1)+" انتخاب شده");refreshServers();});addGap(serverList,6);}
        selectedServer.setText(selected>=0?"سرور "+(selected+1)+" انتخاب شده":"هنوز لینکی اضافه نشده");
    }
    void startVpnPermission(){
        if(selected<0){Toast.makeText(this,"اول یک لینک سرور اضافه کن",Toast.LENGTH_SHORT).show();return;}
        Intent intent=VpnService.prepare(this);
        if(intent!=null)startActivityForResult(intent,VPN_REQUEST);
        else onActivityResult(VPN_REQUEST,RESULT_OK,null);
    }
    @Override protected void onActivityResult(int r,int result,Intent data){super.onActivityResult(r,result,data);if(r==VPN_REQUEST&&result==RESULT_OK){status.setText("مجوز VPN داده شد");Toast.makeText(this,"رابط آماده است؛ برای اتصال واقعی باید موتور Xray اضافه شود.",Toast.LENGTH_LONG).show();}}
    static class GradientDrawableBuilder{
        int color,radius; GradientDrawableBuilder(int c,int r){color=c;radius=r;}
        android.graphics.drawable.GradientDrawable drawable(){android.graphics.drawable.GradientDrawable d=new android.graphics.drawable.GradientDrawable();d.setColor(color);d.setCornerRadius(radius);return d;}
    }
}
